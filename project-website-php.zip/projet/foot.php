<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="s" id="footer">
      <h4> ____________________________________________copyright &copy Yesser Kadhi____________________________________  <?php echo date('D-M-Y'); ?>________________________________________________________</h4>
    </div>
</body>
</html> 