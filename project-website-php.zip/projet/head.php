<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="s" id="header">
      <h4>  <?php echo date('D-M-Y'); ?></h4>
    </div>
</body>
</html>